package com.app.exception;

public class CustomRuntimeException extends RuntimeException{

}
