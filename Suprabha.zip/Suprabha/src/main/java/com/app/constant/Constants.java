package com.app.constant;

public interface Constants {

	Integer MAX_RENEWAL=3;
	Integer MAX_BOOK_ISSUE=4;
	Integer INITIAL_BOOK_OF_MEMBE =0;
	Integer DEFAULT_MEMBER_STATUS=1;
	Float INITIAL_FINE_FOR_MEMBER=0F;
     String USER_ROLE="MEMBER";
	Integer BOOK_RESEVRED=0;
}
